function isCollidedPlot(input)
    for i = input
        x = -1:0.05:1;
        
    end
end