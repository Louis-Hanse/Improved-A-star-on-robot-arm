function p = drawPoint(lineCord)

end