%{
    Function:   创建球体
    Input:      r：     半径
                cord：  球心坐标
                color:  颜色，默认为[24, 90, 189]
    RetVal:     球体的面矩阵
%}
function ball = CreateSphere(r,cord,color)
    if nargin == 2
        color = [24, 90, 189];%默认颜色
    end

    x = cord(1);
    y = cord(2);
    z = cord(3);
    [bx,by,bz] = sphere(36);

    c=zeros(size(bx));%获得大小相同的矩阵
    for i=1:1:length(c(1,:))
        for j=1:1:length(c(:,1))
            c(i,j,1)=color(1)/255;
            c(i,j,2)=color(2)/255;
            c(i,j,3)=color(3)/255;
        end
    end

    ball = surf(bx*r+x,by*r+y,bz*r+z,c,'EdgeColor','none');

end